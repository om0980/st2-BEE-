const express = require('express');
const router = express.Router();
const Product = require('../models/product');


router.get('/', async (req, res) => {
    const { page = 1, pageSize = 10 } = req.query;
    const skip = (page - 1) * pageSize;
  
    try {
      const products = await Product.find().skip(skip).limit(Number(pageSize));
      res.json(products);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  
router.post('/', async (req, res) => {
    const { name, description, price, category } = req.body;
  
    try {
      const newProduct = new Product({
        name,
        description,
        price,
        category,
      });
  
      const savedProduct = await newProduct.save();
      res.status(201).json(savedProduct);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
  
router.get('/:productId', async (req, res) => {
    const { productId } = req.params;
  
    try {
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      res.json(product);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

 
router.put('/:productId', async (req, res) => {
    const { productId } = req.params;
    const { name, description, price, category } = req.body;
  
    try {
      const updatedProduct = await Product.findByIdAndUpdate(
        productId,
        { name, description, price, category },
        { new: true }
      );
  
      if (!updatedProduct) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      res.json(updatedProduct);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
  
router.delete('/:productId', async (req, res) => {
    const { productId } = req.params;
  
    try {
      const deletedProduct = await Product.findByIdAndDelete(productId);
      if (!deletedProduct) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      res.json({ message: 'Product deleted successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
  
  
module.exports = router;
