const express = require('express');
const router = express.Router();
const Product = require('../models/product');


router.post('/', async (req, res) => {
    const { productId } = req.params;
    const { content, rating, author } = req.body;
  
    try {
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      const newReview = {
        content,
        rating,
        author,
      };
  
      product.reviews.push(newReview);
      await product.save();
  
      res.status(201).json(newReview);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });


router.get('/', async (req, res) => {
    const { productId } = req.params;
    const { page = 1, pageSize = 10 } = req.query;
    const skip = (page - 1) * pageSize;
  
    try {
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      const reviews = product.reviews.slice(skip, skip + Number(pageSize));
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
router.put('/:reviewId', async (req, res) => {
    const { productId, reviewId } = req.params;
    const { content, rating, author } = req.body;
  
    try {
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      const review = product.reviews.id(reviewId);
      if (!review) {
        return res.status(404).json({ error: 'Review not found' });
      }
  
      review.content = content;
      review.rating = rating;
      review.author = author;
  
      await product.save();
      res.json(review);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });

  
router.delete('/:reviewId', async (req, res) => {
    const { productId, reviewId } = req.params;
  
    try {
      const product = await Product.findById(productId);
      if (!product) {
        return res.status(404).json({ error: 'Product not found' });
      }
  
      const review = product.reviews.id(reviewId);
      if (!review) {
        return res.status(404).json({ error: 'Review not found' });
      }
  
      review.remove();
      await product.save();
  
      res.json({ message: 'Review deleted successfully' });
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  });
  
  
  

module.exports = router;
